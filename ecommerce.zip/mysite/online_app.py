from pony.orm import Database, Required, Optional, db_session, select, PrimaryKey, Set
from flask import Flask, request, render_template, redirect, url_for, flash, Markup, get_template_attribute, session
from flask_login import current_user, login_user, login_required, logout_user, UserMixin, LoginManager
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config



app = Flask(__name__)
app.config.from_object(Config)
login = LoginManager(app)
login.login_view = 'login'


db = Database()

class Sale(db.Entity):
    name = Required(str)
    size = Required(int)
    address = Required(str)
    productname = Required(str)
    phonenumber = Required(str)


class Product(db.Entity):
    id = PrimaryKey(int, auto = True)
    name = Required(str)
    image_src = Required(str)
    image_src2 = Optional(str)
    image_src3 = Optional(str)
    description = Optional(str)
    price = Required(str)
    category = Required(str)
    users = Optional("User", reverse="wishlist")

class User(UserMixin, db.Entity):
    _table_ = 'users'
    email = Required(str, unique=True)
    username = Required(str, unique=True)
    password_hash = Optional(str)
    wishlist = Set("Product", reverse="users")


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

db.bind(provider='sqlite', filename='productdb', create_db=True)
db.generate_mapping(create_tables=True)

def create_shoes():

    with db_session:
        Product(name='Air Force 1',
        image_src='https://static.nike.com/a/images/t_default/nkj4hukaeyfjq1hefn1b/air-force-1-07-shoe-xmpTzM.png',
        image_src2='https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5,q_80/15bcd4d6-2636-4e9d-8b90-47d556a2cc0a/air-force-1-07-mens-shoes-5QFp5Z.png',
        image_src3='https://static.nike.com/a/images/t_PDP_864_v1/f_auto,b_rgb:f5f5f5,q_80/894df3e6-1f5b-4a0a-8d9d-dc5112833d0c/air-force-1-07-mens-shoes-5QFp5Z.png',
        description='Good shoe ok',
        price="90€",
        category="Men")

        Product(name='Nike Air Vapormax',
        image_src='https://static.nike.com/a/images/t_default/40b7431d-7e46-463d-9c73-b3a0914190e9/air-vapormax-2020-flyknit-shoe-W8qps9.png',
        description='Good shoe ok',
        price="200€",
        category="Men")

        Product(name='Nike Air Max 97',
        image_src='https://static.nike.com/a/images/t_default/4e74d81b-77ec-411b-b598-e0614e9e9b09/air-max-97-se-shoes-wJcltf.png',
        description='Good shoe ok',
        price="170€",
        category="Woman")

        Product(name='Alexander McQueen',
        image_src='https://i.pinimg.com/736x/06/fa/42/06fa426884cb23be4f02f51284e14504.jpg',
        description='Good shoe ok',
        price="200€",
        category="Men")








@db_session
@app.route('/', methods = ['POST', 'GET'])
def home_page():
    #create_shoes()
    products = select(p for p in Product)[:]
    if not products:
        create_shoes()
        products = select(p for p in Product)[:]
    return render_template("index.html", PRODUCTS=products)



@app.route('/productid/<id>')
def product_page(id):
    product = Product[id]
    return render_template("products.html", PRODUCT=product)

@db_session
@app.route('/checkout/<id>', methods = ['POST', 'GET'])

def checkout_page(id):
    product = Product[id]
    if request.method == 'GET':
        return render_template("checkout.html", PRODUCT=product)

@db_session
@app.route('/purchase', methods = ['POST'])
def purchase():

    user_name = request.form['name']
    user_size = request.form['size']
    user_address = request.form['address']
    product_name = request.form['product']
    user_phone = request.form['phone']

    Sale(name=user_name, size=user_size, address=user_address, productname=product_name, phonenumber=user_phone)

    return redirect(url_for('home_page'))

@app.route('/add_to_wishlist/<productid>', methods = ['POST',])
def add_to_wishlist(productid):

    with db_session:
        product = Product.get(id=productid)
        current_user.wishlist.add(product)
        return 'successfully added'


@app.route('/wishlist', methods = ['GET',])
@login_required
def wishlist():

    products = select(p for p in current_user.wishlist)[:]
    return render_template("wishlist.html", PRODUCTS=products)

@app.route('/sales', methods = ['GET',])
@login_required
def sales():

    all_sales = select(s for s in Sale)[:]
    return render_template("purchase.html", SALE=all_sales)

@login.user_loader
@db_session
def load_user(id):
    try:
        return User.get(id=int(id))
    except:
        return


@db_session
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'GET':
        return render_template('signup.html', title='Sign Up')

    elif request.method == 'POST':
        if request.form['password'] == request.form['confirm_password']:
            u = select(user for user in User if user.email==request.form['email'] or user.username==request.form['username'])
            if u.count() != 0:
                flash('Email or username are already in use.', 'red')
                return redirect(url_for('signup'))
            else:
                user = User(username=request.form['username'],
                            email=request.form['email'])
                user.set_password(request.form['password'])
                user = User.get(email=request.form['email'])

                login_user(user, force=True)
                return redirect(url_for('login'))

        else:
            flash('The passwords do not match. Please try again.', 'red')
            return redirect(url_for('signup'))

@db_session
@app.route('/login', methods=['GET', 'POST'])

def login():
    if request.method == 'GET':
        if current_user.is_authenticated:
            return redirect(url_for('home_page'))
        else:
            return render_template('login.html', title='Login')
    elif request.method == 'POST':
        password = request.form['password']
        if '@' in request.form['email']:
            user = User.get(email=request.form['email'])
        else:
            user = User.get(username=request.form['email'])

        if user is None:
            flash(Markup(
                'There\'s no account associated with this email address.'
                '<a href="/signup" style="color:white"><br>Sign up now.</a>'))
            return redirect(url_for('login'))
        elif not user.check_password(password):
            flash('Oops! Wrong credentials. Please try again.')
            return redirect(url_for('login'))
        else:
            login_user(user, force=True)

            return redirect(url_for('home_page'))




@db_session
@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))






